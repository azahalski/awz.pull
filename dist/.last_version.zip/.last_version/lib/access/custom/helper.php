<?php
namespace Awz\Pull\Access\Custom;

class Helper
{
    public const ADMIN_DECLINE = 1;
}
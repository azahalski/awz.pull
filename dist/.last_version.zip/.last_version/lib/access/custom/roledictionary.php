<?php
namespace Awz\Pull\Access\Custom;

use Awz\Pull\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}
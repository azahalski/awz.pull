<?
$arModuleVersion = array(
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2025-05-05 10:00:00"
);
?>
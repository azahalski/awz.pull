<?
$arModuleVersion = array(
	"VERSION" => "1.0.6",
	"VERSION_DATE" => "2025-09-10 13:22:00"
);
?>